import pandas as pd
import os

# Read the CSV file
csv_path = "/Users/ron/Documents/data-practice/data_science_job_project/Data Science Jobs Salaries.csv"
df = pd.read_csv(csv_path)

# Clean column names (remove spaces, special characters, make lowercase)
df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_').str.replace('(', '').str.replace(')', '')

# Create table name from filename
table_name = os.path.basename(csv_path).replace('.csv', '').replace(' ', '_').lower()

# Generate SQL
sql_statements = []

# Create table statement
columns = []
for col_name, dtype in zip(df.columns, df.dtypes):
    if 'int' in str(dtype):
        pg_type = 'INTEGER'
    elif 'float' in str(dtype):
        pg_type = 'NUMERIC'
    elif 'bool' in str(dtype):
        pg_type = 'BOOLEAN'
    elif 'datetime' in str(dtype):
        pg_type = 'TIMESTAMP'
    else:
        pg_type = 'TEXT'
    columns.append(f"{col_name} {pg_type}")

create_table_sql = f"CREATE TABLE IF NOT EXISTS {table_name} (\n    " + ",\n    ".join(columns) + "\n);\n"
sql_statements.append(create_table_sql)

# Insert statements
sql_statements.append(f"-- Insert data\n")
for _, row in df.iterrows():
    values = []
    for val in row:
        if pd.isna(val):
            values.append('NULL')
        elif isinstance(val, str):
            # Escape single quotes
            val_escaped = val.replace("'", "''")
            values.append(f"'{val_escaped}'")
        elif isinstance(val, (int, float)):
            values.append(str(val))
        elif isinstance(val, bool):
            values.append(str(val).upper())
        else:
            values.append(f"'{str(val)}'")
    
    insert_sql = f"INSERT INTO {table_name} ({', '.join(df.columns)}) VALUES ({', '.join(values)});"
    sql_statements.append(insert_sql)

# Write to SQL file
sql_file_path = csv_path.replace('.csv', '.sql')
with open(sql_file_path, 'w', encoding='utf-8') as f:
    f.write('\n'.join(sql_statements))

print(f"SQL file created at: {sql_file_path}")
print(f"Table name: {table_name}")
print(f"Number of rows: {len(df)}")