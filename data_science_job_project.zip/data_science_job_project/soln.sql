select * from data_science_jobs_salaries

-- Beginner Questions:
-- List all columns for employees working in 2021e
select * from data_science_jobs_salaries where work_year = '2021e'
-- Show only job_title and salary_in_usd for all entries
select job_title, salary_in_usd from data_science_jobs_salaries where salary_currency = 'USD'
-- Find all Data Scientists in the dataset
select * from data_science_jobs_salaries where job_title = 'Data Scientist'
-- Count how many employees work full-time (FT)
select count(*) employees_FT from data_science_jobs_salaries where employment_type = 'FT'
-- Show unique job titles in the dataset
select distinct job_title from data_science_jobs_salaries
-- List employees with salary over $100,000
select * from data_science_jobs_salaries where salary > 100000 and salary_currency = 'USD'
-- Find employees who work 100% remotely
select * from data_science_jobs_salaries where remote_ratio = 100
-- Show data where company_size is 'L' (Large)
select * from data_science_jobs_salaries where company_size = 'L'
-- List employees from the US (both employee_residence and company_location)
select * from data_science_jobs_salaries where employee_residence = 'US' and company_location = 'US'
-- Count how many employees are at each experience level (EN, MI, SE, EX)
select experience_level, count(*) count_employees from data_science_jobs_salaries
group by 1 

-- Intermediate Questions:
-- 11. Find the average salary in USD for each experience level
select experience_level, round(avg(salary),2) from data_science_jobs_salaries where salary_currency = 'USD'
group by 1 
-- 12. Show job titles with their average salaries, ordered from highest to lowest
select job_title, round(avg(salary),2) from data_science_jobs_salaries
group by 1 order by 2 desc
-- 13. For each company_location, find the maximum salary offered
select company_location, max(salary) from data_science_jobs_salaries
group by 1
-- 14. Count how many employees work in each country (employee_residence)
select employee_residence, count(*) from data_science_jobs_salaries
group by 1
-- 15. Find the average salary for each combination of experience_level and employment_type
select experience_level, employment_type, round(avg(salary),2) from data_science_jobs_salaries
group by 1,2
-- 16. List employees who earn more than the average salary of all employees
select * from data_science_jobs_salaries where salary > (select avg(salary) from data_science_jobs_salaries)
-- 17. Show the top 5 highest paying job titles
select job_title, max(salary) from data_science_jobs_salaries
group by 1 order by 2 desc limit 5
-- 18. Calculate the salary difference between full-time and part-time employees on average
-- 18. Calculate the salary difference between full-time and part-time employees on average
SELECT 
    (SELECT AVG(salary_in_usd) FROM data_science_jobs_salaries WHERE employment_type = 'FT') -
    (SELECT AVG(salary_in_usd) FROM data_science_jobs_salaries WHERE employment_type = 'PT')
    AS avg_salary_difference_ft_minus_pt;
-- 19. For each year, count how many employees are in each company_size
select work_year, company_size,count(*) from data_science_jobs_salaries
group by 1,2
order by 1
-- 20. Find employees whose remote_ratio doesn't match their location (employee_residence ≠ company_location but remote_ratio is 0)
select * from data_science_jobs_salaries where employee_residence <> company_location



-- Advanced Questions:
-- 21. Calculate the percentage of total salary each employee contributes compared to their job title's total
select job_title,round(salary*100.0/sum(salary) over(partition by job_title),2) ,sum(salary) over(partition by job_title) from data_science_jobs_salaries
order by 1,2
-- 22. Rank employees within each job_title by salary (highest to lowest)
select *, dense_rank() over(partition by job_title order by salary desc) from data_science_jobs_salaries
order by job_title
-- 23. Find the salary gap between the highest and lowest paid employee in each country
select company_location, max(salary) - min(salary) salary_diff from data_science_jobs_salaries
group by 1



-- Additional Questions
-- 24. Calculate moving average of salaries for each experience level (if you had date-based ordering)
select * from data_science_jobs_salaries
-- 25. Find pairs of employees with similar salaries (±5%) but different experience levels
select * from data_science_jobs_salaries where salary = salary
-- 26. For each company_size, show the most common job_title
select * from data_science_jobs_salaries
-- 27. Calculate the correlation between remote_ratio and salary_in_usd (would need more data points)
select * from data_science_jobs_salaries
-- 28. Find employees who earn more than the average of their experience level but less than the average of their job_title
select * from data_science_jobs_salaries
-- 29. Show year-over-year salary growth for continuing positions (if multiple years existed)
select * from data_science_jobs_salaries
-- 30. Identify outliers - employees earning more than 2 standard deviations from their job_title's average
select * from data_science_jobs_salaries

-- Complex Business Questions:
-- 31. Which combination of experience_level and job_title has the highest salary-to-title count ratio?
-- 32. How does salary distribution differ between employees working in their home country vs. abroad?
-- 33. What's the premium (percentage increase) for employees working at US companies vs non-US?
-- 34. For senior positions (SE, EX), which has higher salaries: individual contributors or managers?
-- 35. Analyze if larger companies (L) pay more than smaller ones (S, M) for the same roles