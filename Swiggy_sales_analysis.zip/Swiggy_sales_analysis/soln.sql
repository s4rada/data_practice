select * from swiggy_data;

ALTER TABLE swiggy_data
ALTER COLUMN order_date TYPE DATE 
USING TO_DATE(order_date, 'DD-MM-YYYY');
-- check nulls
select 
sum(case when state is null or state = '' then 1 else 0 end) as state_null,
sum(case when city is null or city = '' then 1 else 0 end) as city_null,
sum(case when order_date::text is null or order_date::text = '' then 1 else 0 end) as order_date_null,
sum(case when restaurant_name is null or restaurant_name = '' then 1 else 0 end) as restaurant_name_null,
sum(case when location is null or location = '' then 1 else 0 end) as location_null,
sum(case when category is null or category = '' then 1 else 0 end) as category_null,
sum(case when dish_name is null or dish_name = '' then 1 else 0 end) as dish_name_null,
sum(case when price_inr::text is null or price_inr::text = '' then 1 else 0 end) as price_inr_null,
sum(case when rating::text is null or rating::text = '' then 1 else 0 end) as rating_null,
sum(case when rating_count::text is null or rating_count::text = '' then 1 else 0 end) as rating_count_null
from swiggy_data;
-- check duplicates
select state,city,order_date,restaurant_name,location,dish_name,price_inr,rating,rating_count,count(*)
from swiggy_data
group by state,city,order_date,restaurant_name,location,dish_name,price_inr,rating,rating_count
having count(*) =1
-- remove duplicates
WITH duplicates AS (
    SELECT 
        ctid,
        ROW_NUMBER() OVER (
            PARTITION BY 
                state,
                city,
                order_date,
                restaurant_name,
                location,
                dish_name,
                price_inr,
                rating,
                rating_count
            ORDER BY ctid
        ) as rn
    FROM swiggy_data
)
DELETE FROM swiggy_data
USING duplicates
WHERE swiggy_data.ctid = duplicates.ctid
  AND duplicates.rn > 1;

-- star schema
CREATE TABLE dim_date (
    date_id SERIAL PRIMARY KEY,
    full_date DATE,
    year INT,
    month_name VARCHAR(20),
    quarter INT,
    day INT,
    week INT
);

create table dim_location(
location_id serial primary key,
state varchar(100),
city varchar(100),
location varchar(200)
)

create table dim_restaurant(
restaurant_id serial primary key,
restaurant_name varchar(200)
)

create table dim_category(
category_id serial primary key,
category varchar(200)
)

create table dim_dish(
dish_id serial primary key,
dish_name varchar(200)
)

create table fact_swiggy_orders(
order_id serial primary key,
date_id int,
price_inr decimal (10,2),
rating decimal (4,2),
rating_count int,

location_id int,
restaurant_id int,
category_id int,
dish_id int,

foreign key (date_id) references dim_date(date_id),
foreign key (location_id) references dim_location(location_id),
foreign key (restaurant_id) references dim_restaurant(restaurant_id),
foreign key (category_id) references dim_category(category_id),
foreign key (dish_id) references dim_dish(dish_id)

)

select * from fact_swiggy_orders
select * from swiggy_data

select * from dim_date

INSERT INTO dim_date (full_date, year, month_name, quarter, day, week)
SELECT DISTINCT 
    order_date,
    EXTRACT(YEAR FROM order_date) AS year,
    TO_CHAR(order_date, 'Month') AS month_name,
    EXTRACT(QUARTER FROM order_date) AS quarter,
    EXTRACT(DAY FROM order_date) AS day,
    EXTRACT(WEEK FROM order_date) AS week
FROM swiggy_data 
WHERE order_date IS NOT NULL;

select * from dim_location
insert into dim_location(state,city,location)
select distinct
state,city,location from swiggy_data

select * from dim_restaurant
insert into dim_restaurant(restaurant_name)
select distinct
restaurant_name from swiggy_data

select * from dim_category
insert into dim_category(category)
select distinct category from swiggy_data

select * from dim_dish

insert into dim_dish(dish_name)
select distinct dish_name from swiggy_data


select * from fact_swiggy_orders

insert into fact_swiggy_orders(date_id, price_inr,rating,rating_count,location_id,restaurant_id,category_id,dish_id)
select dd.date_id,s.price_inr,s.rating,s.rating_count, dl.location_id,dr.restaurant_id,dc.category_id,
dsh.dish_id
from swiggy_data s
join dim_date dd on dd.full_date = s.order_date
join dim_location dl on dl.state = s.state
and dl.city = s.city 
and dl.location = s.location
join dim_restaurant dr on dr.restaurant_name = s.restaurant_name
join dim_category dc on dc.category = s.category
join dim_dish dsh on dsh.dish_name = s.dish_name

-- KPI DEVELOPEMENT
-- 1
select count(*) count_orders from fact_swiggy_orders
-- 2
select sum(price_inr) total_revenue from fact_swiggy_orders
-- 3
select round(avg(price_inr),2) avg_dish_price from fact_swiggy_orders
-- 4
select round(avg(rating),2) avg_rating from fact_swiggy_orders


select * from fact_swiggy_orders f
join dim_date d on f.date_id = d.date_id
join dim_location dl on f.location_id = dl.location_id
join dim_restaurant dr on f.restaurant_id = dr. restaurant_id
join dim_category dc on f.category_id = dc.category_id
join dim_dish dsh on f.dish_id = dsh.dish_id

-- BUSINESS ANALYSIS
-- Monthly Order Trends
-- month
select year,month_name,count(order_id) count_orders from fact_swiggy_orders f
join dim_date d on f.date_id = d.date_id
join dim_location dl on f.location_id = dl.location_id
join dim_restaurant dr on f.restaurant_id = dr. restaurant_id
join dim_category dc on f.category_id = dc.category_id
join dim_dish dsh on f.dish_id = dsh.dish_id
group by 1,2
order by 1,2
-- quarter
select year,quarter,count(order_id) count_orders from fact_swiggy_orders f
join dim_date d on f.date_id = d.date_id
join dim_location dl on f.location_id = dl.location_id
join dim_restaurant dr on f.restaurant_id = dr. restaurant_id
join dim_category dc on f.category_id = dc.category_id
join dim_dish dsh on f.dish_id = dsh.dish_id
group by 1,2
order by 1,2
-- year
select year,count(order_id) count_orders from fact_swiggy_orders f
join dim_date d on f.date_id = d.date_id
join dim_location dl on f.location_id = dl.location_id
join dim_restaurant dr on f.restaurant_id = dr. restaurant_id
join dim_category dc on f.category_id = dc.category_id
join dim_dish dsh on f.dish_id = dsh.dish_id
group by 1
order by 1
-- day-of-week
select extract(dow from full_date),count(order_id) count_orders from fact_swiggy_orders f
join dim_date d on f.date_id = d.date_id
join dim_location dl on f.location_id = dl.location_id
join dim_restaurant dr on f.restaurant_id = dr. restaurant_id
join dim_category dc on f.category_id = dc.category_id
join dim_dish dsh on f.dish_id = dsh.dish_id
group by 1
order by 1 desc

-- top 10 cities by order volume
select city, count(order_id) count_orders from fact_swiggy_orders f
join dim_date d on f.date_id = d.date_id
join dim_location dl on f.location_id = dl.location_id
join dim_restaurant dr on f.restaurant_id = dr. restaurant_id
join dim_category dc on f.category_id = dc.category_id
join dim_dish dsh on f.dish_id = dsh.dish_id
group by 1
order by 2 desc
limit 10



-- Revenue Contribution by state
select state, sum(price_inr) total_revenue from fact_swiggy_orders f
join dim_date d on f.date_id = d.date_id
join dim_location dl on f.location_id = dl.location_id
join dim_restaurant dr on f.restaurant_id = dr. restaurant_id
join dim_category dc on 
f.category_id = dc.category_id
join dim_dish dsh on f.dish_id = dsh.dish_id
group by 1
order by 2 desc
limit 5

-- Top 10 restaurants by orders
select restaurant_name, count(order_id) total_orders from fact_swiggy_orders f
join dim_date d on f.date_id = d.date_id
join dim_location dl on f.location_id = dl.location_id
join dim_restaurant dr on f.restaurant_id = dr. restaurant_id
join dim_category dc on f.category_id = dc.category_id
join dim_dish dsh on f.dish_id = dsh.dish_id
group by 1
order by 2 desc
limit 5

-- Top categories (Indian, Chinese, etc.)
select category, count(order_id) total_orders from fact_swiggy_orders f
join dim_date d on f.date_id = d.date_id
join dim_location dl on f.location_id = dl.location_id
join dim_restaurant dr on f.restaurant_id = dr. restaurant_id
join dim_category dc on f.category_id = dc.category_id
join dim_dish dsh on f.dish_id = dsh.dish_id
group by 1
order by 2 desc
limit 5

-- Most ordered dishes
select dish_name, count(*) count_order from fact_swiggy_orders f
join dim_date d on f.date_id = d.date_id
join dim_location dl on f.location_id = dl.location_id
join dim_restaurant dr on f.restaurant_id = dr. restaurant_id
join dim_category dc on f.category_id = dc.category_id
join dim_dish dsh on f.dish_id = dsh.dish_id
group by 1
order by 2 desc
limit 5
-- Cuisine performance → Orders + Avg Rating
select restaurant_name, count(*) total_orders, avg(rating) avg_rating from fact_swiggy_orders f
join dim_date d on f.date_id = d.date_id
join dim_location dl on f.location_id = dl.location_id
join dim_restaurant dr on f.restaurant_id = dr. restaurant_id
join dim_category dc on f.category_id = dc.category_id
join dim_dish dsh on f.dish_id = dsh.dish_id
group by 1
order by 2 desc ,3 desc

-- customer spending analysis
with cte as(
select
order_id, price_inr,
case 
when price_inr < 100 then 'under 100'
when price_inr < 200 then '100 - 199'
when price_inr < 300 then '200 - 399'
when price_inr < 500 then '300 - 499'
when price_inr >= 500 then '500+'
end as spending_insights
from fact_swiggy_orders f
join dim_date d on f.date_id = d.date_id
join dim_location dl on f.location_id = dl.location_id
join dim_restaurant dr on f.restaurant_id = dr. restaurant_id
join dim_category dc on f.category_id = dc.category_id
join dim_dish dsh on f.dish_id = dsh.dish_id
) 
select spending_insights, count(*) from cte
group by 1 
order by 2 desc

-- rating_analysis
select dish_name, rating from fact_swiggy_orders f
join dim_date d on f.date_id = d.date_id
join dim_location dl on f.location_id = dl.location_id
join dim_restaurant dr on f.restaurant_id = dr. restaurant_id
join dim_category dc on f.category_id = dc.category_id
join dim_dish dsh on f.dish_id = dsh.dish_id
order by 2 desc
