# minimal_csv_to_sql.py
import pandas as pd
import os

def csv_to_sql_simple(csv_path, table_name='swiggy_data'):
    """Simple CSV to SQL converter"""
    
    # Read CSV
    df = pd.read_csv(csv_path)
    
    # Clean column names
    df.columns = [col.strip().replace(' ', '_').replace('(', '').replace(')', '') 
                  for col in df.columns]
    
    # Generate SQL
    sql = f"CREATE TABLE {table_name} (\n"
    
    # Add columns with appropriate types
    for col in df.columns:
        dtype = str(df[col].dtype)
        if dtype == 'int64':
            pg_type = 'INTEGER'
        elif dtype == 'float64':
            pg_type = 'DECIMAL'
        elif dtype == 'bool':
            pg_type = 'BOOLEAN'
        else:
            pg_type = 'TEXT'
        
        sql += f"    {col} {pg_type},\n"
    
    sql = sql.rstrip(',\n') + "\n);\n\n"
    
    # Add INSERT statements
    sql += f"INSERT INTO {table_name} VALUES\n"
    
    values = []
    for _, row in df.iterrows():
        row_values = []
        for val in row:
            if pd.isna(val):
                row_values.append('NULL')
            elif isinstance(val, (int, float)):
                row_values.append(str(val))
            else:
                escaped = str(val).replace("'", "''")
                row_values.append(f"'{escaped}'")
        
        values.append(f"({', '.join(row_values)})")
    
    sql += ",\n".join(values) + ";"
    
    # Save to file
    output_file = csv_path.replace('.csv', '.sql')
    with open(output_file, 'w') as f:
        f.write(sql)
    
    print(f"SQL saved to: {output_file}")
    return output_file

# Usage
if __name__ == "__main__":
    csv_path = '/Users/ron/Documents/data-practice/Swiggy_sales_analysis/Swiggy_Data.csv'
    csv_to_sql_simple(csv_path)